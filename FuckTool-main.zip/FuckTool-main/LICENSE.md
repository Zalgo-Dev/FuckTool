FuckTool License

Copyright (c) 2025 ZalgoDev

---

### 🔹 **1. Utilisation autorisée**
- Ce logiciel peut être utilisé **uniquement dans le cadre de FuckTool**.

---

### 🔹 **2. Interdictions**
- ❌ **Réutilisation interdite** : Il est interdit d'utiliser ce code dans un autre projet quelconque (privé et public).
- ❌ **Modification interdite** : Il est interdit de modifier, transformer ou altérer ce logiciel, même pour un usage personnel. (en dehors des contributions)
- ❌ **Distribution interdite** : Il est interdit de redistribuer ce logiciel sous quelque forme que ce soit.
- ❌ **Vente interdite** : Ce logiciel ne peut être vendu ou utilisé dans un but commercial.
- ❌ **Aucune publication non autorisée** : Vous ne pouvez pas publier ce code, modifié ou non, sur GitHub, GitLab, ou toute autre plateforme.

---

### 🔹 **3. Contribution**
- ✅ **Les contributions sont acceptées**, mais **chaque modification doit être soumise** à l’auteur pour validation.
- ✅ Les contributeurs **ne deviennent pas propriétaires** du code qu'ils soumettent.
- ✅ Toute contribution acceptée devient **propriété de FuckTool**.

---

### 🔹 **4. Clause de non-responsabilité**
- Ce logiciel est fourni **"tel quel"**, sans garantie d'aucune sorte.
- L’auteur **ne peut être tenu responsable** de tout dommage ou utilisation abusive du logiciel.

---

📌 **Pour toute demande d'autorisation ou soumission de code :**  
__📧 Contact :__
Discord : [zalgodev]
